import json
import time
from pathlib import Path
from benchmarks.attention_harness.robosuite_memory.formal_service import DedicatedRobosuiteService
from benchmarks.attention_harness.robosuite_memory.adapter import RobosuiteSimGTBackend
from benchmarks.attention_harness.robosuite_memory.discover_variations import discover_cases

root = Path('/home/truares/桌面/attentionbench-memory-effect-20260927')
with DedicatedRobosuiteService(
    source_root=Path('/home/truares/桌面/robosuite_sim-service'),
    expected_revision='12bc69afe83c8398988be3eee637f91c14e9bf19',
    log_path=root/'discovery_service.log', deadline=time.monotonic()+180,
) as service:
    cases = discover_cases(
        'cube_lift', seeds=(101, 102, 103, 104, 105),
        cameras=('agentview', 'robot0_eye_in_hand'),
        task_prompts=('Lift the cube clear of the table.', 'Pick up the cube from the table.'),
        adapter_factory=lambda task, camera: RobosuiteSimGTBackend(
            task, service_url=service.base_url, camera_name=camera,
            camera_height=64, camera_width=64,
        ),
    )
    (root/'cases.json').write_text(json.dumps(cases, indent=2, sort_keys=True)+'\n')
print(json.dumps({'cases': cases, 'service_stop': service.stop_receipt}, indent=2))
