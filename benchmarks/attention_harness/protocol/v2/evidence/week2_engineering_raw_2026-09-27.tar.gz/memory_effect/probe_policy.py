"""Development probe of the public SDK repair suggested by the Advisor."""

def move(sdk, target, gripper_command, steps=100):
    sdk.arm.move_to_position(*target, max_steps=steps)


def policy(sdk, context):
    cube = next(item["position"] for item in sdk.sensors.find_objects(["cube"])
                if item["name"] == "cube")
    sdk.gripper.open(settle_steps=1)
    move(sdk, [cube[0], cube[1], cube[2] + 0.12], -1.0)
    move(sdk, [cube[0], cube[1], cube[2] + 0.005], -1.0)
    sdk.gripper.close(settle_steps=30)
    move(sdk, [cube[0], cube[1], 1.08], 1.0)
    sdk.gripper.close(settle_steps=10)
