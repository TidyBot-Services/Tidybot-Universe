import hashlib
import json
from pathlib import Path

from attention_memory_service import MemoryService
from benchmarks.attention_harness.core.store import AttentionStore
from benchmarks.attention_harness.memory_agent import MemoryAgent
from benchmarks.attention_harness.sim_gt_memory import policy_fingerprint
from validation_policy import policy

root = Path('/home/truares/桌面/attentionbench-memory-effect-20260927')
source = Path('/home/truares/桌面/attentionbench-glm-closure-20260927/robosuite/attention-robosuite-cube_lift-seed101-001c01c7e0a0')
memory_id = 'candidate:attempt:attention-robosuite-cube_lift-seed101-001c01c7e0a0:0'
cases = tuple(json.loads((root/'cases.json').read_text()))
store = AttentionStore(source/'attention.sqlite3')
service = MemoryService(store, artifact_root=source/'attempts')
agent = MemoryAgent(service)
fingerprint = policy_fingerprint(policy)
preflight = agent.preflight_validation(memory_id, cases=cases, assistance_credits=0,
                                       validation_policy_sha256=fingerprint)
assert preflight['source_evidence_verified'] and not preflight['frozen_plan']
freeze = {
    'schema_version': 'attentionbench.memory-real-effect-freeze.v1',
    'formal_eligible': False,
    'suite': 'robosuite', 'task_id': 'cube_lift', 'perception_mode': 'sim_gt',
    'memory_id': memory_id, 'policy_id': 'reactive_help',
    'policy_file': str((root/'validation_policy.py').resolve()),
    'policy_file_sha256': hashlib.sha256((root/'validation_policy.py').read_bytes()).hexdigest(),
    'policy_fingerprint_sha256': fingerprint,
    'source_policy_sha256': preflight['source_policy_sha256'],
    'service_revision': '12bc69afe83c8398988be3eee637f91c14e9bf19',
    'memory_service_revision': '24d414638ad2cdd6557f09f042e8b6ef2b597b0f',
    'universe_revision': '02817128f6133fd0aef2407ed8f053d07633d1a0',
    'cases': list(cases),
    'execution': {
        'assistance_credits': 0, 'token_limit': 30000,
        'attention_run_budget_seconds': 300.0,
        'service_process_deadline_seconds': 600.0,
        'horizon': 500, 'camera_height': 64, 'camera_width': 64,
        'max_delta_m': 0.25, 'max_observed_step_m': 0.5,
        'control': 'same callback with empty Memory catalog and no candidate exposure',
        'treatment': 'same callback with exactly this candidate exposed and explicit retrieval',
        'order': 'ascending seed; control then treatment; never replace or omit a planned case',
    },
    'decision_rule': {
        'all_planned_cases_paired': True,
        'minimum_distinct_dev_seeds': 5,
        'treatment_safety_regressions': 0,
        'treatment_success_regressions': 0,
        'minimum_treatment_successes': 3,
        'minimum_treatment_success_fraction': 0.75,
        'positive_success_gain_or_both_success_help_saving': True,
    },
    'preflight': preflight,
}
with (root/'freeze.json').open('x') as output:
    json.dump(freeze, output, indent=2, sort_keys=True)
    output.write('\n')
agent.plan_validation(memory_id, cases=cases, assistance_credits=0)
print(json.dumps({'freeze_sha256': hashlib.sha256((root/'freeze.json').read_bytes()).hexdigest(),
                  'policy_fingerprint': fingerprint, 'plan_recorded': True}, indent=2))
