import hashlib
import json
from pathlib import Path
from attention_memory_service import MemoryService
from benchmarks.attention_harness.core.store import AttentionStore

root = Path('/home/truares/桌面/attentionbench-memory-effect-20260927')
source = Path('/home/truares/桌面/attentionbench-glm-closure-20260927/robosuite/attention-robosuite-cube_lift-seed101-001c01c7e0a0')
audit = json.loads((root/'audit.json').read_text())
assert all(audit['promotion_gate_precheck'].values())
assert len(audit['pairs']) == 5
store = AttentionStore(source/'attention.sqlite3')
service = MemoryService(store, artifact_root=source/'attempts')
memory_id = audit['memory_id']
before = service.get_memory(memory_id)
assert before.status.value == 'candidate'
after = service.promote(memory_id)
assert after.status.value == 'trusted'
package = service.export_package(memory_id)
verification = service.verify_package(memory_id)
receipt = {
    'schema_version': 'attentionbench.memory-real-effect-promotion.v1',
    'formal_eligible': False, 'memory_id': memory_id,
    'audit_uri': str((root/'audit.json').resolve()),
    'audit_sha256': hashlib.sha256((root/'audit.json').read_bytes()).hexdigest(),
    'status_before': before.status.value, 'status_after': after.status.value,
    'version_before': before.version, 'version_after': after.version,
    'package_uri': str(package.resolve()), 'package_verification': verification,
}
(root/'promotion.json').write_text(json.dumps(receipt, indent=2, sort_keys=True, default=str)+'\n')
print(json.dumps(receipt, indent=2, sort_keys=True, default=str))
