import hashlib
import json
import shutil
import sqlite3
import time
from pathlib import Path

from attention_memory_service import MemoryService
from benchmarks.attention_harness.core.store import AttentionStore
from benchmarks.attention_harness.robosuite_memory.formal_service import DedicatedRobosuiteService
from benchmarks.attention_harness.robosuite_memory.adapter import RobosuiteSimGTBackend
from benchmarks.attention_harness.robosuite_memory.sim_gt_runner import run_robosuite_sim_gt_episode
from benchmarks.attention_harness.robocasa_native.safety_monitor import SafetyMonitorBackend
from validation_policy import policy

root = Path('/home/truares/桌面/attentionbench-memory-effect-20260927')
source = Path('/home/truares/桌面/attentionbench-glm-closure-20260927/robosuite/attention-robosuite-cube_lift-seed101-001c01c7e0a0')
freeze = json.loads((root/'freeze.json').read_text())
memory_id = freeze['memory_id']
case = freeze['cases'][1]
context = {'suite': 'robosuite', 'task_id': 'cube_lift', 'perception_mode': 'sim_gt',
           **{key: value for key, value in case.items() if key != 'seed'}}
store = AttentionStore(source/'attention.sqlite3')
service = MemoryService(store, artifact_root=source/'attempts')
assert service.get_memory(memory_id).status.value == 'trusted'
assert [item.memory_id for item in service.retrieve(context, now=time.time())] == [memory_id]
scope_tests = {}
for key, replacement in (
    ('scene_id', 'scene:outside'), ('object_set_id', 'objects:outside'),
    ('camera_config_id', 'camera:outside'), ('task_variant_id', 'task-variant-outside'),
    ('camera_names', ['agentview']), ('task_prompt', 'Move a different object.'),
    ('task_id', 'cube_stack'), ('perception_mode', 'vision'),
):
    changed = {**context, key: replacement}
    scope_tests[key] = [item.memory_id for item in service.retrieve(changed, now=time.time())]
    assert scope_tests[key] == []

output = root/'post_promotion_run'
output.mkdir(exist_ok=True)
with DedicatedRobosuiteService(
    source_root=Path('/home/truares/桌面/robosuite_sim-service'),
    expected_revision=freeze['service_revision'],
    log_path=output/'service.log', deadline=time.monotonic()+180,
) as active:
    adapter = RobosuiteSimGTBackend('cube_lift', service_url=active.base_url,
        camera_name=case['camera_names'][0], horizon=500, camera_height=64, camera_width=64)
    monitor = SafetyMonitorBackend(adapter, max_delta_m=0.25, max_observed_step_m=0.5)
    result = run_robosuite_sim_gt_episode(
        task_id='cube_lift', seed=case['seed'], artifact_root=output,
        adapter=adapter, action_backend=monitor, policy=policy,
        policy_id='reactive_help', perception_mode='sim_gt',
        runtime_variation={key: value for key, value in case.items() if key != 'seed'},
        retrieve_memory=True, advisor_transport=None, assistance_credits=0,
        store_path=store.path, memory_gateway=service,
    )
    episode = Path(result['artifact_dir'])
    safety_path = monitor.write_artifact(episode/'safety_monitor.json',
                                         attempt_id=result['attention_trace']['attempt_id'])
    adapter.close()
assert result['status'] == 'completed' and result['native_success'] is True
assert result['formal_eligible'] is False
safety = json.loads(safety_path.read_text())
assert safety['unsafe_attempts'] == 0
raw = store.get_raw_trace(result['attention_trace']['raw_trace_id'])
retrievals = [event for event in raw['events'] if event['event_type'] == 'attention.memory_retrieval']
assert len(retrievals) == 1
retrieval = retrievals[0]
assert retrieval['arguments']['memory_id'] == memory_id
assert retrieval['result']['memory_version'] == 1
assert isinstance(retrieval['result']['grant_id'], str)
assert raw['outcome']['native_success'] is True and raw['outcome']['evaluator_authoritative'] is True
uses = [item for item in store.list_memory_uses(memory_id)
        if item['attempt_id'] == result['attention_trace']['attempt_id']]
assert len(uses) == 1 and uses[0]['memory_version'] == 1
assert uses[0]['outcome'] == 'native_success'
(episode/'raw_trace.json').write_text(json.dumps(raw, indent=2, sort_keys=True)+'\n')
(episode/'memory_use.json').write_text(json.dumps(uses[0], indent=2, sort_keys=True)+'\n')

# Exercise real Memory Service transitions against a SQLite backup, retaining
# the promoted production candidate available for future development runs.
clone = root/'lifecycle_clone'
clone.mkdir(exist_ok=True)
with sqlite3.connect(store.path) as original, sqlite3.connect(clone/'attention.sqlite3') as backup:
    original.backup(backup)
for ref in service.provenance(memory_id)['raw_evidence_refs']:
    relative = Path(ref['uri'].removeprefix('artifact://'))
    target = clone/relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source/'attempts'/relative, target)
clone_service = MemoryService(AttentionStore(clone/'attention.sqlite3'), artifact_root=clone)
assert [item.memory_id for item in clone_service.retrieve(context, now=time.time())] == [memory_id]
disabled = clone_service.disable(memory_id, actor='memory_effect_validation',
    reason='lifecycle revocation test on isolated authority snapshot')
assert disabled.status.value == 'disabled'
assert clone_service.retrieve(context, now=time.time()) == []
disable_blocked = False
try:
    clone_service.authorize_use(context, memory_id=memory_id,
        attempt_id='attempt:disabled-check', now=time.time())
except Exception:
    disable_blocked = True
assert disable_blocked
rolled_back = clone_service.rollback(memory_id, actor='memory_effect_validation',
    reason='lifecycle rollback test on isolated authority snapshot')
assert rolled_back.status.value == 'rolled_back'
assert clone_service.retrieve(context, now=time.time()) == []
rollback_blocked = False
try:
    clone_service.authorize_use(context, memory_id=memory_id,
        attempt_id='attempt:rollback-check', now=time.time())
except Exception:
    rollback_blocked = True
assert rollback_blocked
assert [item.memory_id for item in service.retrieve(context, now=time.time())] == [memory_id]

def file_ref(path):
    return {'uri': str(path.resolve()), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
receipt = {
    'schema_version': 'attentionbench.memory-post-promotion.v1',
    'formal_eligible': False, 'memory_id': memory_id,
    'scope_in_match': True, 'scope_out_of_match': scope_tests,
    'run': {
        'run_id': result['attention_trace']['run_id'],
        'attempt_id': result['attention_trace']['attempt_id'],
        'native_success': True, 'unsafe_attempts': 0,
        'memory_version': 1, 'grant_id': retrieval['result']['grant_id'],
        'use_id': uses[0]['use_id'], 'recorded_use_outcome': uses[0]['outcome'],
        'artifacts': {name: file_ref(episode/name) for name in
                      ('result.json','trace.jsonl','raw_trace.json','memory_use.json',
                       'safety_monitor.json','attention_bundle.json')},
        'service_stop': active.stop_receipt,
    },
    'lifecycle_clone': {
        'database': file_ref(clone/'attention.sqlite3'),
        'disabled_status': disabled.status.value,
        'disabled_retrieval_empty': True, 'disabled_grant_blocked': disable_blocked,
        'rollback_status': rolled_back.status.value,
        'rollback_retrieval_empty': True, 'rollback_grant_blocked': rollback_blocked,
        'production_memory_still_trusted': service.get_memory(memory_id).status.value == 'trusted',
    },
}
(root/'post_promotion.json').write_text(json.dumps(receipt, indent=2, sort_keys=True)+'\n')
print(json.dumps(receipt, indent=2, sort_keys=True))
