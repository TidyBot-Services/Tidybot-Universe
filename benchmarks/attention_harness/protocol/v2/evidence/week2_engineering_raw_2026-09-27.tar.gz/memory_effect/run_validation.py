import hashlib
import json
import subprocess
import time
from pathlib import Path

from attention_memory_service import MemoryService
from benchmarks.attention_harness.core.store import AttentionStore
from benchmarks.attention_harness.memory_agent import MemoryAgent
from benchmarks.attention_harness.robosuite_memory.formal_service import DedicatedRobosuiteService
from benchmarks.attention_harness.robosuite_memory.adapter import RobosuiteSimGTBackend
from benchmarks.attention_harness.robosuite_memory.paired_trials import RobosuitePairedTrialExecutor
from benchmarks.attention_harness.sim_gt_memory import policy_fingerprint
from validation_policy import policy

root = Path('/home/truares/桌面/attentionbench-memory-effect-20260927')
source = Path('/home/truares/桌面/attentionbench-glm-closure-20260927/robosuite/attention-robosuite-cube_lift-seed101-001c01c7e0a0')
freeze = json.loads((root/'freeze.json').read_text())
execution_freeze = json.loads((root/'execution_fingerprint_freeze.json').read_text())
memory_id = freeze['memory_id']
cases = tuple(freeze['cases'])
assert hashlib.sha256((root/'validation_policy.py').read_bytes()).hexdigest() == freeze['policy_file_sha256']
actual_fingerprint = policy_fingerprint(policy)
assert hashlib.sha256((root/'freeze.json').read_bytes()).hexdigest() == execution_freeze['parent_freeze_sha256']
assert execution_freeze['policy_file_sha256'] == freeze['policy_file_sha256']
assert actual_fingerprint == execution_freeze['runner_policy_fingerprint_sha256']
for checkout, expected in (
    (Path('/home/truares/桌面/Tidybot-Universe-attention-native'), freeze['universe_revision']),
    (Path('/home/truares/桌面/attention_memory_service'), freeze['memory_service_revision']),
    (Path('/home/truares/桌面/robosuite_sim-service'), freeze['service_revision']),
):
    assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=checkout, text=True).strip() == expected
store = AttentionStore(source/'attention.sqlite3')
service = MemoryService(store, artifact_root=source/'attempts')
agent = MemoryAgent(service)
preflight = agent.preflight_validation(memory_id, cases=cases, assistance_credits=0,
                                       validation_policy_sha256=actual_fingerprint)
assert preflight['frozen_plan'] and not preflight['completed_seeds']
trials = agent.plan_validation(memory_id, cases=cases, assistance_credits=0)
output = root/'validation'
output.mkdir(exist_ok=True)
progress = output/'progress.jsonl'
with DedicatedRobosuiteService(
    source_root=Path('/home/truares/桌面/robosuite_sim-service'),
    expected_revision=freeze['service_revision'],
    log_path=output/'service.log', deadline=time.monotonic()+600,
) as active:
    executor = RobosuitePairedTrialExecutor(
        policy=policy, policy_id=freeze['policy_id'], artifact_root=output,
        store_path=store.path, memory_gateway=service,
        adapter_factory=lambda task, camera: RobosuiteSimGTBackend(
            task, service_url=active.base_url, camera_name=camera,
            horizon=500, camera_height=64, camera_width=64,
        ),
    )
    for control, treatment in trials:
        control_evidence = executor(control)
        treatment_evidence = executor(treatment)
        assert control_evidence.config_sha256 == treatment_evidence.config_sha256
        pair = service.record_pair(
            memory_id=memory_id,
            control_attempt_id=control_evidence.attempt_id,
            treatment_attempt_id=treatment_evidence.attempt_id,
            control_safety=control_evidence.safety_artifact,
            treatment_safety=treatment_evidence.safety_artifact,
        )
        with progress.open('a') as stream:
            stream.write(json.dumps({'seed': control.seed, 'pair': pair}, sort_keys=True)+'\n')
        print(json.dumps({'seed': control.seed, 'control': control_evidence.attempt_id,
                          'treatment': treatment_evidence.attempt_id,
                          'pair_status': pair.get('status')}, sort_keys=True), flush=True)
    impact = service.impact_report(memory_id)
    (output/'impact.json').write_text(json.dumps(impact, indent=2, sort_keys=True)+'\n')
print(json.dumps({'service_stop': active.stop_receipt,
                  'impact': impact}, indent=2, sort_keys=True))
