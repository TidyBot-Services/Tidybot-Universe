import hashlib
import json
from pathlib import Path

from attention_memory_service import MemoryService
from benchmarks.attention_harness.core.store import AttentionStore

root = Path('/home/truares/桌面/attentionbench-memory-effect-20260927')
source = Path('/home/truares/桌面/attentionbench-glm-closure-20260927/robosuite/attention-robosuite-cube_lift-seed101-001c01c7e0a0')
freeze = json.loads((root/'freeze.json').read_text())
execution_freeze = json.loads((root/'execution_fingerprint_freeze.json').read_text())
memory_id = freeze['memory_id']
store = AttentionStore(source/'attention.sqlite3')
service = MemoryService(store, artifact_root=source/'attempts')
plan = service.get_plan(memory_id)
pairs = service.list_pairs(memory_id)
impact = service.impact_report(memory_id)
assert plan['cases'] == freeze['cases']
assert [pair['seed'] for pair in pairs] == [case['seed'] for case in freeze['cases']]
assert len(pairs) == 5 and impact['paired_dev_seeds'] == 5
assert impact['control_successes'] == 0 and impact['treatment_successes'] == 5
assert impact['success_gain'] == 5 and not impact['safety_regressions']
assert not impact['counterexamples'] and len(impact['validated_scope']) == 5

configs = {}
for path in (root/'validation').glob('*/trial_config.json'):
    config = json.loads(path.read_text())
    configs[config['attempt_id']] = (config, path.parent)
assert len(configs) == 10

def evidence(path):
    return {'uri': str(path.resolve()), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

audited = []
for pair, case in zip(pairs, freeze['cases']):
    rows = []
    for arm in ('control', 'treatment'):
        attempt_id = pair[f'{arm}_attempt_id']
        config, directory = configs[attempt_id]
        assert config['arm'] == arm and config['seed'] == case['seed']
        assert config['variation'] == {k: v for k, v in case.items() if k != 'seed'}
        assert config['policy_sha256'] == execution_freeze['runner_policy_fingerprint_sha256']
        result = json.loads((directory/'result.json').read_text())
        safety = json.loads((directory/'safety_monitor.json').read_text())
        raw = store.get_raw_trace(config['raw_trace_id'])
        attempt = store.get_attempt(attempt_id)
        assert attempt['native_success'] == result['native_success'] == raw['outcome']['native_success']
        assert raw['outcome']['evaluator_authoritative'] is True
        assert result['formal_eligible'] is False and result['status'] == 'completed'
        assert safety['source'] == 'independent_safety_monitor' and safety['unsafe_attempts'] == 0
        assert safety['violations'] == []
        assert evidence(directory/'safety_monitor.json')['sha256'] == pair[f'{arm}_safety']['sha256']
        retrievals = [event for event in raw['events'] if event['event_type'] == 'attention.memory_retrieval']
        catalogs = [event for event in raw['events'] if event['event_type'] == 'attention.memory_catalog']
        assert len(catalogs) == 1
        if arm == 'control':
            assert not retrievals and catalogs[0]['result']['memory_ids'] == []
            assert result['native_success'] is False
        else:
            assert len(retrievals) == 1 and retrievals[0]['arguments']['memory_id'] == memory_id
            assert retrievals[0]['result']['memory_version'] == 1
            assert catalogs[0]['result']['memory_ids'] == [memory_id]
            assert result['native_success'] is True
        files = {name: evidence(directory/name) for name in
                 ('trial_config.json', 'result.json', 'trace.jsonl', 'trace_context.json',
                  'attention_bundle.json', 'safety_monitor.json')}
        rows.append({
            'arm': arm, 'attempt_id': attempt_id, 'raw_trace_id': config['raw_trace_id'],
            'native_evaluator_authoritative': True, 'native_success': result['native_success'],
            'unsafe_attempts': safety['unsafe_attempts'], 'retrieval_count': len(retrievals),
            'memory_version': retrievals[0]['result']['memory_version'] if retrievals else None,
            'config_sha256': config['config_sha256'], 'files': files,
        })
    assert rows[0]['config_sha256'] == rows[1]['config_sha256']
    audited.append({'seed': case['seed'], 'variation': case,
                    'config_sha256': rows[0]['config_sha256'], 'arms': rows,
                    'counterexample': False})

provenance = service.provenance(memory_id)
raw_source = store.get_raw_trace(provenance['source_raw_trace_id'])
response = store.get_response(provenance['response_id'])
trace = store.get_trace(provenance['source_trace_id'])
assert raw_source and response and trace
archive = root/'source_lineage'
archive.mkdir(exist_ok=True)
for name, value in [('raw_trace.json', raw_source), ('advisor_response.json', response),
                    ('advisor_trace.json', trace), ('provenance.json', provenance)]:
    (archive/name).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')
lineage = {name: evidence(archive/name) for name in
           ('raw_trace.json', 'advisor_response.json', 'advisor_trace.json', 'provenance.json')}
lineage['guidance'] = evidence(source/'memory'/next((source/'memory').iterdir()).name/'knowledge/guidance.md')
lineage['repair'] = evidence(source/'memory'/next((source/'memory').iterdir()).name/'knowledge/repair.md')
for ref in provenance['raw_evidence_refs']:
    path = source/'attempts'/ref['uri'].removeprefix('artifact://')
    assert evidence(path)['sha256'] == ref['sha256']
lineage['raw_source_evidence_refs_verified'] = provenance['raw_evidence_refs']

audit = {
    'schema_version': 'attentionbench.memory-real-effect-audit.v1',
    'formal_eligible': False, 'memory_id': memory_id,
    'freeze': evidence(root/'freeze.json'),
    'execution_fingerprint_freeze': evidence(root/'execution_fingerprint_freeze.json'),
    'source': lineage, 'pairs': audited, 'impact': impact,
    'promotion_gate_precheck': {
        'all_cases_paired': len(audited) == len(freeze['cases']),
        'no_safety_regression': not impact['safety_regressions'],
        'no_success_regression': impact['success_gain'] >= 0,
        'minimum_successes': impact['treatment_successes'] >= 3,
        'minimum_success_fraction': impact['treatment_successes']/len(audited) >= 0.75,
        'measured_benefit': impact['success_gain'] > 0 or impact['both_success_assistance_credits_saved'] > 0,
    },
}
assert all(audit['promotion_gate_precheck'].values())
(root/'audit.json').write_text(json.dumps(audit, indent=2, sort_keys=True)+'\n')
print(json.dumps({'audit': evidence(root/'audit.json'), 'pairs': len(audited),
                  'promotion_gate_precheck': audit['promotion_gate_precheck']}, indent=2))
