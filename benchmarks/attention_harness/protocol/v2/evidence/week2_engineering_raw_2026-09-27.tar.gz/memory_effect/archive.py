import hashlib
import json
import sqlite3
from pathlib import Path

from attention_memory_service import MemoryService
from benchmarks.attention_harness.core.store import AttentionStore

root = Path('/home/truares/桌面/attentionbench-memory-effect-20260927')
source = Path('/home/truares/桌面/attentionbench-glm-closure-20260927/robosuite/attention-robosuite-cube_lift-seed101-001c01c7e0a0')
freeze = json.loads((root/'freeze.json').read_text())
audit = json.loads((root/'audit.json').read_text())
promotion = json.loads((root/'promotion.json').read_text())
post = json.loads((root/'post_promotion.json').read_text())
store = AttentionStore(source/'attention.sqlite3')
service = MemoryService(store, artifact_root=source/'attempts')
assert service.get_memory(freeze['memory_id']).status.value == 'trusted'

def ref(path):
    return {'uri': str(path.resolve()), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

trace_refs = []
for pair in audit['pairs']:
    arms = []
    for arm in pair['arms']:
        raw = store.get_raw_trace(arm['raw_trace_id'])
        episode = Path(arm['files']['result.json']['uri']).parent
        path = episode/'raw_trace.json'
        with path.open('x') as output:
            json.dump(raw, output, indent=2, sort_keys=True)
            output.write('\n')
        assert raw['outcome']['native_success'] == arm['native_success']
        arms.append({'arm': arm['arm'], 'raw_trace_id': arm['raw_trace_id'],
                     'raw_trace': ref(path), 'result': arm['files']['result.json'],
                     'safety': arm['files']['safety_monitor.json'],
                     'trial_config': arm['files']['trial_config.json']})
    trace_refs.append({'seed': pair['seed'], 'arms': arms})

snapshot = root/'authority_snapshot.sqlite3'
with sqlite3.connect(store.path) as original, sqlite3.connect(snapshot) as backup:
    original.backup(backup)
manifest = {
    'schema_version': 'attentionbench.memory-real-effect-archive.v1',
    'formal_eligible': False,
    'memory_id': freeze['memory_id'], 'final_memory_status': 'trusted',
    'versions': {
        'universe': freeze['universe_revision'],
        'memory_service': freeze['memory_service_revision'],
        'robosuite_service': freeze['service_revision'],
    },
    'source_lineage': audit['source'],
    'preregistration': ref(root/'freeze.json'),
    'execution_fingerprint_freeze': ref(root/'execution_fingerprint_freeze.json'),
    'variation_discovery': ref(root/'cases.json'),
    'audit': ref(root/'audit.json'),
    'promotion': ref(root/'promotion.json'),
    'post_promotion': ref(root/'post_promotion.json'),
    'authority_snapshot': ref(snapshot),
    'pairs': trace_refs,
    'results': {
        'pairs_completed': 5, 'control_successes': 0,
        'treatment_successes': 5, 'treatment_success_fraction': 1.0,
        'treatment_unsafe_attempts': 0, 'safety_regressions': 0,
        'counterexamples': [],
        'treatment_success_rate_95ci': audit['impact']['treatment_success_rate_95ci'],
        'success_gain': 5, 'assistance_credits_saved': 0,
    },
    'limitations': [
        'Development-only sim_gt trusted callback, not a formal seven-policy result.',
        'The validation callback executes a reviewed public SDK repair when the candidate is exposed; this does not test a general Dev model generating a repair unaided.',
        'Independent Safety covers command envelope and proprioception, with no collision telemetry.',
        'The original source run memory view predates this validation; SQLite snapshot and the regenerated attempts/memory package are authoritative.',
    ],
}
(root/'archive_manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True)+'\n')
print(json.dumps({'archive_manifest': ref(root/'archive_manifest.json'),
                  'authority_snapshot': ref(snapshot), 'paired_raw_traces': 10}, indent=2))
