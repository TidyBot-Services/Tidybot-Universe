import json
import sys
import time
from pathlib import Path

from benchmarks.attention_harness.robosuite_memory.formal_service import DedicatedRobosuiteService
from benchmarks.attention_harness.robosuite_memory.adapter import RobosuiteSimGTBackend
from benchmarks.attention_harness.robosuite_memory.sim_gt_runner import run_robosuite_sim_gt_episode
from benchmarks.attention_harness.robocasa_native.safety_monitor import SafetyMonitorBackend
from probe_policy import policy

root = Path('/home/truares/桌面/attentionbench-memory-effect-20260927/probe')
root.mkdir(parents=True, exist_ok=True)
with DedicatedRobosuiteService(
    source_root=Path('/home/truares/桌面/robosuite_sim-service'),
    expected_revision='12bc69afe83c8398988be3eee637f91c14e9bf19',
    log_path=root/'service.log', deadline=time.monotonic()+240,
) as service:
    adapter = RobosuiteSimGTBackend('cube_lift', service_url=service.base_url,
                                     camera_name='agentview', camera_height=64, camera_width=64)
    monitor = SafetyMonitorBackend(adapter, max_delta_m=0.25, max_observed_step_m=0.5)
    result = run_robosuite_sim_gt_episode(
        task_id='cube_lift', seed=int(sys.argv[1]), artifact_root=root,
        adapter=adapter, action_backend=monitor, policy=policy,
        policy_id='reactive_help', perception_mode='sim_gt', retrieve_memory=False,
        assistance_credits=0,
    )
    print(json.dumps({key: result.get(key) for key in ('artifact_dir','status','native_success','error','policy_sha256')}, indent=2))
    monitor.write_artifact(Path(result['artifact_dir'])/'safety_monitor.json',
                           attempt_id=result['attention_trace']['attempt_id'])
    adapter.close()
