#!/usr/bin/env python3
"""Auto-generated code execution wrapper."""

import sys
import os

# Add parent directory to path so robot_sdk can be imported
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Initialize robot_sdk with backend connections
from backends.franka import FrankaBackend
from backends.base import BaseBackend
from backends.gripper import GripperBackend
from backends.mocap import MocapBackend
from config import FrankaBackendConfig, BaseBackendConfig, GripperBackendConfig, MocapBackendConfig, TimingConfig
from robot_sdk import ArmAPI, BaseAPI, GripperAPI, SensorAPI, YoloAPI, WholeBodyAPI, GraspGenAPI

timing = TimingConfig()
import robot_sdk

# Create backend configurations (use environment variables or defaults)
import asyncio

dry_run = os.getenv("ROBOT_DRY_RUN", "false").lower() == "true"

franka_config = FrankaBackendConfig(
    host=os.getenv("FRANKA_IP", "localhost"),
    cmd_port=int(os.getenv("FRANKA_CMD_PORT", "5555")),
    state_port=int(os.getenv("FRANKA_STATE_PORT", "5556")),
    stream_port=int(os.getenv("FRANKA_STREAM_PORT", "5557")),
)

base_config = BaseBackendConfig(
    host=os.getenv("BASE_IP", "localhost"),
    port=int(os.getenv("BASE_PORT", "50000")),
    authkey=b"secret password",
)

gripper_config = GripperBackendConfig(
    host=os.getenv("GRIPPER_IP", "localhost"),
    cmd_port=int(os.getenv("GRIPPER_CMD_PORT", "5570")),
    state_port=int(os.getenv("GRIPPER_STATE_PORT", "5571")),
)

mocap_config = MocapBackendConfig(
    host=os.getenv("MOCAP_IP", "localhost"),
    pub_port=int(os.getenv("MOCAP_PUB_PORT", "5590")),
)

# Create backends
franka_backend = FrankaBackend(franka_config, dry_run=dry_run)
base_backend = BaseBackend(base_config, dry_run=dry_run)
gripper_backend = GripperBackend(gripper_config, dry_run=dry_run)
mocap_backend = MocapBackend(mocap_config, dry_run=dry_run)

# Connect to backends (gracefully handle unavailable ones)
async def init_backends():
    # Franka (arm) - required
    try:
        await franka_backend.connect()
        print("[SDK] Franka backend connected")
    except Exception as e:
        print(f"[SDK] WARNING: Franka backend unavailable: {e}")

    # Base - optional
    try:
        await base_backend.connect()
        print("[SDK] Base backend connected")
    except Exception as e:
        print(f"[SDK] WARNING: Base backend unavailable: {e}")

    # Gripper - optional
    try:
        await gripper_backend.connect()
        print("[SDK] Gripper backend connected")
    except Exception as e:
        print(f"[SDK] WARNING: Gripper backend unavailable: {e}")

    # Mocap - optional
    try:
        await mocap_backend.connect()
        print("[SDK] Mocap backend connected")
    except Exception as e:
        print(f"[SDK] WARNING: Mocap backend unavailable: {e}")

asyncio.run(init_backends())

# Initialize SDK global instances
robot_sdk.arm = ArmAPI(
    franka_backend,
    motion_timeout=timing.motion_timeout_s,
    settle_timeout=timing.settle_timeout_s,
    command_rate_hz=timing.arm_command_rate_hz,
    converge_pos_m=timing.arm_converge_pos_m,
    converge_joint_rad=timing.arm_converge_joint_rad,
    converge_vel=timing.arm_converge_vel,
)
robot_sdk.base = BaseAPI(
    base_backend,
    mocap_backend=mocap_backend,
    timeout=timing.base_timeout_s,
    position_tolerance_m=timing.base_position_tolerance_m,
    angle_tolerance_rad=timing.base_angle_tolerance_rad,
)
robot_sdk.gripper = GripperAPI(gripper_backend)

# Initialize rewind API (uses HTTP calls to agent server)
from robot_sdk.rewind import RewindAPI
server_url = os.getenv("ROBOT_SERVER_URL", "http://localhost:8080")

robot_sdk.sensors = SensorAPI(franka_backend, base_backend, gripper_backend, agent_server_url=server_url, mocap_backend=mocap_backend)
lease_id = os.getenv("ROBOT_LEASE_ID")
robot_sdk.rewind = RewindAPI(server_url=server_url, lease_id=lease_id)
print(f"[SDK] Rewind API initialized (server: {server_url})")

# Initialize YOLO API (uses HTTP calls to remote YOLO server + agent server cameras)
from robot_sdk.yolo import YoloAPI
robot_sdk.yolo = YoloAPI(
    yolo_server_url=os.getenv("YOLO_SERVER_URL", ""),
    agent_server_url=server_url,
)
print("[SDK] YOLO API initialized")

# Initialize GraspGen API (uses HTTP calls to remote GraspGen server + agent server cameras)
from robot_sdk.graspgen import GraspGenAPI
robot_sdk.graspgen = GraspGenAPI(
    graspgen_server_url=os.getenv("GRASPGEN_SERVER_URL", ""),
    agent_server_url=server_url,
)
print("[SDK] GraspGen API initialized")

# Initialize display API (uses HTTP calls to agent server)
from robot_sdk.display import DisplayAPI
robot_sdk.display = DisplayAPI(server_url=server_url)
print("[SDK] Display API initialized")

# Initialize whole-body motion API (uses planning server)
from robot_sdk.wb import WholeBodyAPI
planner_url = os.getenv("PLANNER_URL", "http://localhost:5500")
robot_sdk.wb = WholeBodyAPI(
    arm_backend=franka_backend,
    base_backend=base_backend,
    planner_url=planner_url,
)
print(f"[SDK] Whole-body API initialized (planner: {planner_url})")

# Initialize generic HTTP client (for calling any external service)
from robot_sdk import http as _http_module
robot_sdk.http = _http_module
print("[SDK] HTTP client initialized")

# Make them available for import
arm = robot_sdk.arm
base = robot_sdk.base
gripper = robot_sdk.gripper
sensors = robot_sdk.sensors
rewind = robot_sdk.rewind
yolo = robot_sdk.yolo
graspgen = robot_sdk.graspgen
display = robot_sdk.display
wb = robot_sdk.wb
http = robot_sdk.http

# Apply robot-profile capability filter: replace any disabled-capability
# SDK globals with CapabilityStub so calls raise CapabilityNotAvailableError
# instead of trying to use disconnected backends. No-op if ROBOT_CAPABILITIES
# env var is unset (back-compat).
from robot_sdk import apply_capability_filter as _apply_capability_filter
_apply_capability_filter()
# Re-bind locals after filtering, so user code sees stubs for disabled modules.
arm      = robot_sdk.arm
base     = robot_sdk.base
gripper  = robot_sdk.gripper
sensors  = robot_sdk.sensors
rewind   = robot_sdk.rewind
yolo     = robot_sdk.yolo
graspgen = robot_sdk.graspgen
display  = robot_sdk.display
wb       = robot_sdk.wb

# Also expose backends directly for advanced usage
# (same pattern as rewind orchestrator uses)

# ============================================================================
# USER CODE STARTS HERE
# ============================================================================

from robot_sdk import arm
arm.move_delta(dx=0.0, dy=0.0, dz=0.0, droll=0.0, dpitch=0.0, dyaw=-0.8, frame='base')


# ============================================================================
# USER CODE ENDS HERE
# ============================================================================

# Cleanup (disconnect backends)
async def cleanup():
    await franka_backend.disconnect()
    await base_backend.disconnect()
    await gripper_backend.disconnect()
    await mocap_backend.disconnect()

asyncio.run(cleanup())
