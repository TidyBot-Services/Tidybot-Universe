Failure hypothesis: Visible grasp approach needs lower, precise placement.
Proposed change: AB_CONTROL_V1 grasp_offset_m=.005;approach_tolerance_m=.004;close_settle_steps=30;
Caution: Retain the independent Safety envelope.
